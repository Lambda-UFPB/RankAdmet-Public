import importlib.resources as pkg_resources
from .Output import *
from .Merge import *
import pandas as pd
import numpy as np 
import json
import os

class Evaluate:

    def __log(self, message: str):
        if self.verbose:
            print(message)

    @staticmethod
    def json():
        try:
            with pkg_resources.open_text('rankadmet', 'weights.json') as json_file:
                weights = json.load(json_file)
        except:
            with open('C:/Users/julio/Documentos/Projetos/admetscore/source/rankadmet/weights.json') as json_file:
                weights = json.load(json_file)

        new_json_path = os.path.join(os.getcwd(), 'weights.json')
        
        if not os.path.exists(new_json_path):
            with open(new_json_path, 'w') as new_json_file:
                json.dump(weights, new_json_file, indent=4)
        else:
            pass

    @staticmethod
    def _replace_string(value, string, value1, value2): 
        return value1 if value == string else value2
    
    @staticmethod
    def __normalize_values(value):
        if value <= 1.0:
            return float(value * 1000)
        return value

    @staticmethod
    def __rename(df):
        df = df.rename(columns={
            'cl-plasma': 'cl_plasma',
            't0.5': 't_0_5',
            'MCE-18': 'MCE_18',
            })
        return df

    def score_admetlab(self, df):
        self.json()
        with open('weights.json','r') as json_file:
            weights = json.load(json_file)

        df = self.__rename(df)

        try:
            df.drop('molstr',axis=1,inplace=True)
        except:
            pass

        df.replace('Invalid Molecule', np.nan, inplace=True)
        df = df.dropna(how='all', axis=1) 
        df_original = df.copy()

        physicochemical_property_score = ['MW','logD','nHet','nHD','nRing','nRig','logP','MaxRing','TPSA','nHA','nRot','nStereo','fChar','logS']
        new_cols_to_move = ['SCORE','MEDICINAL_CHEMISTRY','Synthesis_profile','Drug_likeness_profile','Physicochemical_Property','TOXICOPHORE_RULES','ABSORTION', 'DISTRIBUTION', 'METABOLISM','EXCRETION' ,'TOXICITY', 'TOX21_PATHWAY']
        physicochemical_property = ['MW', 'Vol', 'Dense', 'nHA', 'nHD', 'TPSA', 'nRot', 'nRing', 'MaxRing', 'nHet', 'fChar', 'nRig', 'Flex', 'nStereo','logS','logD','logP','mp','bp','pka_acidic','pka_basic','LD50_oral','Other_assay_interference']

        # Medicinal Chemistry
        medicinal_chemistry_columns_str = ['Alarm_NMR', 'BMS', 'Chelating', 'PAINS']
        medicinal_chemistry_columns_float_divergent = ['gasa', 'QED', 'Synth', 'Fsp3', 'MCE_18', 'Lipinski', 'Pfizer', 'GSK', 'GoldenTriangle']
        medicinal_chemistry_columns_float_similar = ['Aggregators', 'Fluc', 'Blue_fluorescence', 'Green_fluorescence', 'Reactive', 'Promiscuous']
        medicinal_chemistry = medicinal_chemistry_columns_str + medicinal_chemistry_columns_float_divergent + medicinal_chemistry_columns_float_similar
        medicinal_chemistry_columns_to_move = ['QED','Synth','gasa','Fsp3','MCE_18','Natural Product-likeness','Lipinski','Pfizer','GSK','GoldenTriangle','PAINS','Alarm_NMR','BMS','Chelating','Aggregators','Fluc','Blue_fluorescence','Green_fluorescence','Reactive','Promiscuous']
        medicinal_chemistry_columns_synthesis = ['Synth','MCE_18','gasa','Fsp3']
        medicinal_chemistry_columns_drug_likeness = ['QED','Lipinski','Pfizer','GSK','GoldenTriangle']

        # Toxicophore Rules
        toxicophore_columns = ['NonBiodegradable', 'NonGenotoxic_Carcinogenicity', 'SureChEMBL', 'Skin_Sensitization', 'Acute_Aquatic_Toxicity', 'Genotoxic_Carcinogenicity_Mutagenicity','FAF-Drugs4 Rule']

        # Absorption
        absorption_columns = ['PAMPA', 'pgp_inh', 'pgp_sub', 'hia', 'f20', 'f30', 'f50'] 
        absorption_columns_to_move = ['caco2','MDCK','PAMPA','pgp_inh','pgp_sub','hia','f20','f30','f50'] 

        # Distribution
        distribution_columns = ['OATP1B1', 'OATP1B3', 'BCRP', 'BSEP', 'BBB', 'MRP1'] 
        distribution_columns_to_move = ['PPB','logVDss','BBB','Fu','OATP1B1','OATP1B3','BCRP','MRP1','BSEP']

        # Metabolism
        metabolism_columns = ['CYP1A2-inh', 'CYP1A2-sub', 'CYP2C19-inh', 'CYP2C19-sub', 'CYP2C9-inh', 'CYP2C9-sub', 'CYP2D6-inh', 'CYP2D6-sub', 'CYP3A4-inh', 'CYP3A4-sub', 'CYP2B6-inh', 'CYP2B6-sub', 'CYP2C8-inh', 'LM-human']

        # Excretion
        excretion = ['cl_plasma','t_0_5']

        # Toxicity
        toxicity_columns = ['hERG' , 'hERG-10um' , 'DILI' , 'Ames' , 'ROA' , 'FDAMDD' , 'SkinSen', 'Carcinogenicity','EC' , 'EI' , 'Respiratory' , 'H-HT' , 'Nephrotoxicity-DI', 'Neurotoxicity-DI' , 'Ototoxicity' , 'Hematotoxicity' , 'Genotoxicity' , 'RPMI-8226' , 'A549' , 'HEK293' ,]
        toxicity_columns_to_move = toxicity_columns + ['BCF','IGC50','LC50DM','LC50FM']

        # Tox21
        tox21_columns = ['NR-AhR','NR-AR','NR-AR-LBD','NR-Aromatase','NR-ER','NR-ER-LBD','NR-PPAR-gamma','SR-ARE','SR-ATAD5','SR-HSE','SR-MMP','SR-p53']

        # normalization
        to_normalize = ['caco2','PPB', 'Fu','logVDss','cl_plasma', 't_0_5', 'QED', 'Synth', 'Fsp3', 'MCE_18']

        for coluna in to_normalize:
            df[coluna] = pd.to_numeric(df[coluna], errors='coerce')
            try:
                df[coluna] = df[coluna].apply(self.__normalize_values)
            except TypeError as e:
                print(f"error in the {coluna} column")
                raise e

        for col in toxicophore_columns:
            df[col] = df[col].apply(self._replace_string, args=("['-']", 0, 1))

        for col in medicinal_chemistry_columns_str:
            df[col] = df[col].apply(self._replace_string, args=("['-']", 0, 1))

        df = (
            df.assign(
                caco2=pd.to_numeric(df['caco2'], errors='coerce').apply(lambda x: 0 if x > -5150 else 1),
                MDCK=pd.to_numeric(df['MDCK'], errors='coerce').apply(lambda x: 0 if x > 2e-6 else 1),

                PPB=pd.to_numeric(df['PPB'], errors='coerce').apply(lambda x: 0 if x <= 90 else 1),
                Fu=pd.to_numeric(df['Fu'], errors='coerce').apply(lambda x: 0 if x >= 5 else 1),
                logVDss=pd.to_numeric(df['logVDss'], errors='coerce').apply(lambda x: 0 if 40 <= x <= 200 else 1),

                cl_plasma=pd.to_numeric(df['cl_plasma'], errors='coerce').apply(lambda x: 0 if 0 <= x <= 5 else (0.5 if 5 < x <= 15 else 1)),
                t_0_5=pd.to_numeric(df['t_0_5'], errors='coerce').apply(lambda x: 0 if x > 8 else (0.5 if 1 <= x <= 8 else 1)),

                Lipinski=pd.to_numeric(df['Lipinski'], errors='coerce').apply(lambda x: 0 if x == 0 else 1),
                Pfizer=pd.to_numeric(df['Pfizer'], errors='coerce').apply(lambda x: 0 if x == 0 else 1),
                GSK=pd.to_numeric(df['GSK'], errors='coerce').apply(lambda x: 0 if x == 0 else 1),
                GoldenTriangle=pd.to_numeric(df['GoldenTriangle'], errors='coerce').apply(lambda x: 0 if x == 0 else 1),

                QED=pd.to_numeric(df['QED'], errors='coerce').apply(lambda x: 0 if x > 670 else (0.5 if 490 <= x <= 670 else 1)),
                Synth=pd.to_numeric(df['Synth'], errors='coerce').apply(lambda x: 0 if x <= 6.0 else 1),
                Fsp3=pd.to_numeric(df['Fsp3'], errors='coerce').apply(lambda x: 0 if x >= 420 else 1),
                MCE_18=pd.to_numeric(df['MCE_18'], errors='coerce').apply(lambda x: 0 if x >= 45.0 else 1),

                MW=pd.to_numeric(df['MW'], errors='coerce').apply(lambda x: 0 if 100 <= x <= 600 else 1),
                logD=pd.to_numeric(df['logD'], errors='coerce').apply(lambda x: 0 if 1 <= x <= 3 else 1),
                nHet=pd.to_numeric(df['nHet'], errors='coerce').apply(lambda x: 1 if x <= 15 else 1),
                nHD=pd.to_numeric(df['nHD'], errors='coerce').apply(lambda x: 0 if x <= 7 else 1),
                nRing=pd.to_numeric(df['nRing'], errors='coerce').apply(lambda x: 0 if x <= 6 else 1),
                nRig=pd.to_numeric(df['nRig'], errors='coerce').apply(lambda x: 0 if x <= 30 else 1),
                logP=pd.to_numeric(df['logP'], errors='coerce').apply(lambda x: 0 if 3 <= x <= 5 else 1),
                MaxRing=pd.to_numeric(df['MaxRing'], errors='coerce').apply(lambda x: 0 if 0 <= x <= 18 else 1),
                TPSA=pd.to_numeric(df['TPSA'], errors='coerce').apply(lambda x: 0 if 0 <= x <= 140 else 1),
                nHA=pd.to_numeric(df['nHA'], errors='coerce').apply(lambda x: 0 if 0 <= x <= 12 else 1),
                nRot=pd.to_numeric(df['nRot'], errors='coerce').apply(lambda x: 0 if 0 <= x <= 11 else 1),
                nStereo=pd.to_numeric(df['nStereo'], errors='coerce').apply(lambda x: 0 if x <= 2 else 1),
                fChar=pd.to_numeric(df['fChar'], errors='coerce').apply(lambda x: 0 if -4 <= x <= 4 else 1),
                logS=pd.to_numeric(df['logS'], errors='coerce').apply(lambda x: 0 if -4 <= x <= 0.5 else 1),
            ))
        
        # df['BCRP'] = 1 - df['BCRP']
        # df['LM-human'] = 1 - df['LM-human']

        n_absorption = len(absorption_columns + ['caco2','MDCK'])
        n_distribution = len(['PPB', 'Fu','logVDss'] + distribution_columns)
        n_toxicity = len(toxicity_columns)
        n_tox21 = len(tox21_columns)
        n_metabolism = len(metabolism_columns)
        n_toxicophore = len(toxicophore_columns)
        n_excretion = len(['cl_plasma', 't_0_5'])
        n_medicinal = len(medicinal_chemistry)
        n_drug_likeness = len(medicinal_chemistry_columns_drug_likeness)
        n_synthesis = len(medicinal_chemistry_columns_synthesis)
        n_physicochemical_property_score = len(physicochemical_property_score)

        new_cols = pd.DataFrame({
            'Physicochemical_Property': df[physicochemical_property_score].sum(axis=1, skipna=True) / n_physicochemical_property_score,
            'ABSORTION': df[absorption_columns + ['caco2','MDCK']].sum(axis=1, skipna=True) / n_absorption,
            'DISTRIBUTION': df[['PPB', 'Fu','logVDss'] + distribution_columns].sum(axis=1, skipna=True) / n_distribution,
            'TOXICITY': df[toxicity_columns].sum(axis=1, skipna=True) / n_toxicity,
            'TOX21_PATHWAY': df[tox21_columns].sum(axis=1, skipna=True) / n_tox21,
            'METABOLISM': df[metabolism_columns].sum(axis=1, skipna=True) / n_metabolism,
            'TOXICOPHORE_RULES': df[toxicophore_columns].sum(axis=1, skipna=True) / n_toxicophore,
            'EXCRETION': df[['cl_plasma', 't_0_5']].sum(axis=1, skipna=True) / n_excretion,
            'MEDICINAL_CHEMISTRY': df[medicinal_chemistry].sum(axis=1, skipna=True) / n_medicinal,
            'Synthesis_profile': df[medicinal_chemistry_columns_synthesis].sum(axis=1, skipna=True) / n_synthesis,
            'Drug_likeness_profile': df[medicinal_chemistry_columns_drug_likeness].sum(axis=1, skipna=True) / n_drug_likeness
        })

        df = pd.concat([df, new_cols], axis=1)

        df['SCORE'] = (df['ABSORTION'] * weights['ABSORTION'] +
                df['DISTRIBUTION'] * weights ['DISTRIBUTION'] +
                df['TOXICITY'] * weights ['TOXICITY'] +
                df['TOX21_PATHWAY'] * weights ['TOX21_PATHWAY'] +
                df['METABOLISM'] * weights['METABOLISM'] +
                df['TOXICOPHORE_RULES'] * weights ['TOXICOPHORE_RULES'] +
                df['EXCRETION'] * weights['EXCRETION'] +
                df['MEDICINAL_CHEMISTRY'] * weights['MEDICINAL_CHEMISTRY']) / sum(weights.values())
        
        df = pd.merge(df_original, df[['smiles'] + new_cols_to_move], on='smiles', how='left')

        new_cols = new_cols_to_move + ['smiles'] + [col for col in df.columns if col not in new_cols_to_move and col not in ['smiles']]
        
        colunas_para_planilha = [new_cols_to_move + ['smiles'] + medicinal_chemistry_columns_to_move + absorption_columns_to_move + distribution_columns_to_move + metabolism_columns + excretion + toxicity_columns_to_move + toxicophore_columns + tox21_columns + physicochemical_property]

        df = df[new_cols]
           
        try:
            df.drop('molstr',axis=1,inplace=True)
        except:
            pass

        df = self.__rename(df)

        df.replace('Invalid Molecule', np.nan, inplace=True)
        df = df.dropna(how='all', axis=1) 

        for coluna in to_normalize:
            df[coluna] = pd.to_numeric(df[coluna], errors='coerce')
            df[coluna] = df[coluna].apply(self.__normalize_values)

        colunas_para_planilha_flat = [col for sublist in colunas_para_planilha for col in (sublist if isinstance(sublist, list) else [sublist])]

        df = df[[col for col in colunas_para_planilha_flat if col in df.columns]]

        return df

    def score_swissadme(self, df):

        df_original = df.copy()

        df = df.rename(
            columns={
            'Consensus Log P': 'Consensus_Log_P',
            'Synthetic Accessibility': 'Synthetic_Accessibility',
            'ESOL Log S': 'ESOL_Log_S',
            'Ali Log S': 'Ali_Log_S',
            'Silicos-IT LogSw': 'Silicos_IT_LogSw',
            'Lipinski #violations': 'Lipinski_violations',
            'Bioavailability Score': 'Bioavailability_Score',
            'log Kp (cm/s)': 'log_Kp',
            })

        yes_no = ['BBB permeant', 'Pgp substrate', 'CYP1A2 inhibitor', 'CYP2C19 inhibitor', 'CYP2C9 inhibitor', 'CYP2D6 inhibitor', 'CYP3A4 inhibitor']
        alerts = ['Ghose #violations','Veber #violations','Egan #violations','Muegge #violations','PAINS #alerts','Brenk #alerts','Leadlikeness #violations']

        df['Bioavailability_Score'] = 1 - df['Bioavailability_Score']

        for col in yes_no:
            df[col] = df[col].apply(self._replace_string, args=("No", 0, 1))

        for col in alerts:
            df[col] = pd.to_numeric(df[col], errors='coerce').apply(lambda x: 0 if x == 0 else 1)

        df['GI absorption'] = df['GI absorption'].apply(self._replace_string, args=("High", 0, 1))
        df['Synthetic_Accessibility'] = df['Synthetic_Accessibility'].apply(lambda x: float(x) / 10)
        df['log_Kp'] = df['log_Kp'].apply(lambda x: abs(float(x) / 10))
        df = (
            df.assign(
                Consensus_Log_P=pd.to_numeric(df['Consensus_Log_P'], errors='coerce').apply(lambda x: 0 if 0 <= x <= 3 else 1),
                MW=pd.to_numeric(df['MW'], errors='coerce').apply(lambda x: 0 if 100 <= x <= 600 else 1),
                TPSA=pd.to_numeric(df['TPSA'], errors='coerce').apply(lambda x: 0 if 0 <= x <= 140 else 1),
                Lipinski_violations=pd.to_numeric(df['Lipinski_violations'], errors='coerce').apply(lambda x: 0 if x < 2 else 1),

                ESOL_Log_S=pd.to_numeric(df['ESOL_Log_S'], errors='coerce').apply(lambda x: 0 if -4 <= x <= 0.5 else 1),
                Ali_Log_S=pd.to_numeric(df['Ali_Log_S'], errors='coerce').apply(lambda x: 0 if -4 <= x <= 0.5 else 1),
                Silicos_IT_LogSw=pd.to_numeric(df['Silicos_IT_LogSw'], errors='coerce').apply(lambda x: 0 if -4 <= x <= 0.5 else 1),
            ))
        
        to_sum = ['Consensus_Log_P', 'MW', 'TPSA', 'Lipinski_violations', 'ESOL_Log_S', 'Ali_Log_S', 'Silicos_IT_LogSw','Bioavailability_Score','BBB permeant', 'Pgp substrate', 'CYP1A2 inhibitor', 'CYP2C19 inhibitor', 'CYP2C9 inhibitor', 'CYP2D6 inhibitor', 'CYP3A4 inhibitor','Ghose #violations','Veber #violations','Egan #violations','Muegge #violations','PAINS #alerts','Brenk #alerts','Leadlikeness #violations','GI absorption','Synthetic_Accessibility','log_Kp',]

        n_to_sum = len(to_sum)  
        
        new_cols = pd.DataFrame({
            'SCORE': df[to_sum].sum(axis=1, skipna=True) / n_to_sum
        })

        df = pd.concat([df_original, new_cols], axis=1)

        df = df.rename(
            columns={
            'Canonical SMILES': 'smiles',
            'log Kp (cm/s)': 'log_Kp',
            'Synthetic Accessibility': 'Synthetic_Accessibility',
            }
        )

        df['log_Kp'] = df['log_Kp'].apply(lambda x: abs(float(x) / 10))
        df['Synthetic_Accessibility'] = df['Synthetic_Accessibility'].apply(lambda x: float(x) / 10)

        return df

    @staticmethod
    def addon_verification(df, addon):
        if isinstance(addon, str):
            if addon.endswith('.sdf'):
                df, first_prop_name = Merge().extract(df, addon)
            elif addon.endswith('.csv'):
                addon = pd.read_csv(addon)
                first_prop_name = addon.columns[1]
                df, first_prop_name = Merge()._merge_with_approximation(df, addon, first_prop_name)

            new_cols = ['ID_Molecula', first_prop_name, 'Match', 'SCORE'] + [col for col in df.columns if col not in ['ID_Molecula', first_prop_name, 'Match', 'SCORE']]
            df = df[new_cols]
            return df, first_prop_name

        elif isinstance(addon, pd.DataFrame):
            df, first_prop_name = Merge().extract(df, addon)
            return df, first_prop_name

    def admetlab(
            self,
            input: str,
            addon: str = None,
            top_hits: int = 50,
            verbose: bool = False
    ) -> None:
        '''
        Use this function to generate a score spreadsheet using an ADMET analysis CSV file from the ADMETlab 3.0 website as input.

        Args:
            input (str or pd.DataFrame): Path to the input CSV file or a DataFrame containing molecular data.
            addon (str, optional): Path to an add-on file for additional data processing. Default is None.
            top_hits (int): Number of top hits to include in the output. Default is 50.

        Returns:
            None

        Example:
            Evaluate().admetlab("molecules.csv", "addon.csv", 10)
        '''
        self.verbose = verbose
        if isinstance(input, str):
            self.__log(f"Reading input file: {input}")
            csv_file = pd.read_csv(input)
        elif isinstance(input, pd.DataFrame):
            self.__log("Using input DataFrame")
            csv_file = input

        df = self.score_admetlab(csv_file)

        first_prop_name = None
        if addon is not None:
            self.__log(f"Processing addon file: {addon}")
            df, first_prop_name = self.addon_verification(df, addon)

        self.__log("Generating output for admetlab")
        Output().output_handled(df, top_hits, 'admetlab', first_prop_name, verbose)

    def swissadme(
            self, 
            input: str,
            addon: str = None,
            top_hits: int = 50,
            verbose: bool = False
    ) -> None:
        '''
        Use this function to generate a score spreadsheet using an ADMET analysis CSV file from the swissadme website as input.

        Args:
            input (str or pd.DataFrame): Path to the input CSV file or a DataFrame containing molecular data.
            addon (str): Path to an add-on file for additional data processing. Default is None.
            top_hits (int): Number of top hits to include in the output. Default is 50.

        Returns:
            None

        Example:
           Evaluate().swissadme("molecules.csv", "addon.csv", 5)
        '''
        self.verbose = verbose
        if isinstance(input, str):
            self.__log(f"Reading input file: {input}")
            csv_file = pd.read_csv(input)
        elif isinstance(input, pd.DataFrame):
            self.__log("Using input DataFrame")
            csv_file = input
        first_prop_name = None

        df = self.score_swissadme(csv_file)

        if addon is not None:
            self.__log(f"Processing addon file: {addon}")
            df, first_prop_name = self.addon_verification(df, addon)
        else:
            new_cols = ['SCORE'] + [col for col in df.columns if col != 'SCORE']
            df = df[new_cols]

        df = df.drop('Molecule', axis=1)

        self.__log("Generating output for swissadme")
        Output().output_handled(df, top_hits, 'swissadme', first_prop_name, verbose)
