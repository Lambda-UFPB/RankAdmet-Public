from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.edge.service import Service as EdgeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.common.by import By
from rich.progress import Progress, TextColumn, BarColumn, TaskProgressColumn
from rich.console import Console
from selenium import webdriver
from .Evaluate import *
import tempfile
import shutil
import time
import os

console = Console()

class BrowserHandler:

    @staticmethod
    def __wait_for_download(directory, timeout=600):
        end_time = time.time() + timeout
        while time.time() < end_time:
            files = [f for f in os.listdir(directory) if not f.endswith('.crdownload')]
            if files:
                return os.path.join(directory, files[0])
            time.sleep(1)
        return None
    
    def run_tasks(self, best_hits_number):
        with Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
        ) as progress:
            print('')
            try:
                print('  Establishing connection with AdmetLab 3.0...')
                options = None
                service = None
                driver = None

                browsers = [
                    ('chrome', webdriver.ChromeOptions, ChromeService, ChromeDriverManager),
                    ('edge', webdriver.EdgeOptions, EdgeService, EdgeChromiumDriverManager),
                    ('firefox', webdriver.FirefoxOptions, FirefoxService, GeckoDriverManager)
                ]

                for browser, Options, Service, DriverManager in browsers:
                    try:
                        options = Options()
                        service = Service(DriverManager().install())
                        options.add_argument('--headless')
                        options.add_argument('--disable-gpu')
                        options.add_argument('--no-sandbox')
                        options.add_argument('--disable-dev-shm-usage')
                        options.add_argument('--log-level=3')
                        options.add_argument('--disable-logging')

                        download_dir = os.path.join(tempfile.gettempdir(), 'admetlab_downloads')
                        if not os.path.exists(download_dir):
                            os.makedirs(download_dir)

                        options.add_experimental_option('prefs', {
                            'download.default_directory': download_dir,
                            'download.prompt_for_download': False,
                            'download.directory_upgrade': True,
                            'safebrowsing.enabled': True
                        })

                        if browser == 'chrome':
                            driver = webdriver.Chrome(service=service, options=options)
                        elif browser == 'edge':
                            driver = webdriver.Edge(service=service, options=options)
                        elif browser == 'firefox':
                            driver = webdriver.Firefox(service=service, options=options)

                        driver.get('https://admetlab3.scbdd.com/server/screening')
                        print(f'  Connection established with {browser}\n')
                        break
                    except Exception as e:
                        console.print(f"[yellow]Failed to establish connection with {browser}: {e}[/yellow]")
                        driver = None

                if driver is None:
                    raise Exception("Failed to establish connection with any browser.")

                input_dir = 'batchs'
                output_dir = 'admetlab3_files'

                if not os.path.exists(output_dir):
                    os.makedirs(output_dir)

                files = [f for f in os.listdir(input_dir) if os.path.isfile(os.path.join(input_dir, f)) and 'ok' not in f]

                overall_task = progress.add_task(f"[#FFFFFF]Processing {len(files)} files...", total=len(files))

                for file in files:

                    file_path = os.path.join(input_dir, file)

                    file_task = progress.add_task(f"[#7B7B7B]Processing {os.path.basename(file)}", total=100)

                    absolute_file_path = os.path.abspath(file_path)

                    upload_element = driver.find_element(By.ID, 'molecule-file')
                    upload_element.send_keys(absolute_file_path)

                    submit_button = driver.find_element(By.XPATH, "//button[@class='btn btn-success' and @onclick='submit1()']")

                    for i in range(1, 31):
                        progress.update(file_task, completed=i)
                        time.sleep(0.009)

                    print('  Uploading file to website...')

                    submit_button.click()

                    progress.console.print("  waiting for download,""[yellow] it may take a few minutes")

                    progress.update(file_task, completed=45)

                    download_button = WebDriverWait(driver, 600).until(
                        EC.visibility_of_element_located((By.XPATH, "//button[@class='btn btn-outline-success' and @onclick='download()']"))
                    )

                    download_button.click()
                    progress.update(file_task, completed=60)

                    downloaded_file_path = self.__wait_for_download(download_dir)
                    print('  Download completed\n')
                
                    if downloaded_file_path:
                        new_file_name = os.path.splitext(file)[0] + '.csv'
                        new_file_path = os.path.join(output_dir, new_file_name)
                        os.rename(downloaded_file_path, new_file_path)
                        csv_directory = 'admetlab3_files'
                        sdf_directory = 'batchs'

                        for i in range(61, 99):
                            progress.update(file_task, completed=i)
                            time.sleep(0.009)

                        for csv_file in os.listdir(csv_directory):
                            if csv_file.endswith('.csv') and not csv_file.endswith('ok.csv'):
                                csv_path = os.path.join(csv_directory, csv_file)
                                sdf_file = os.path.join(sdf_directory, csv_file.replace('.csv', '.sdf'))
                                if os.path.exists(sdf_file):
                                    df = pd.read_csv(csv_path)
                                    progress.update(file_task, completed=100)
                                    progress.update(overall_task, advance=1)
                                    df = Evaluate().score_admetlab(df)
                                    df, first_prop_name = Merge().extract(df, sdf_file)
                                    Output().output_handled(df, best_hits_number, 'admetlab', first_prop_name,verbose=True)

                                    os.remove(sdf_file)
                                    os.remove(csv_path)

                    driver.get('https://admetlab3.scbdd.com/server/screening')

                shutil.rmtree(download_dir)
            
                driver.quit()

            except Exception as e:
                console.print(f"[red]Error: {e}[/red]")
                return