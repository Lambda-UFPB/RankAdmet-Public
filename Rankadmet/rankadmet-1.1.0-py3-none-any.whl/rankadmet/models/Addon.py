from .Merge import *
import tempfile
import datetime
import os
import re

class Addon:

    def __log(self, message: str):
        if self.verbose:
            print(message)

    @staticmethod
    def _extract_database_name(input_file):
        with open(input_file, 'r') as file:
            input_content = file.read()

        molecules = input_content.split('$$$$')

        for molecule in molecules:
            lines = molecule.strip().splitlines()
            if lines:
                first_line = lines[0].strip()
                if first_line:
                    first_id = first_line.split()[0]
                    if re.match(r'^[A-Z]{14}-[A-Z]{10}-[A-Z]$', first_id):
                        return "MCULE_ULTIMATE"
                    elif '-' in first_id:
                        database_name = first_id.split('-')[0]
                    else:
                        match = re.match(r"^([A-Za-z]+)", first_id)
                        if match:
                            database_name = match.group(1)
                        else:
                            database_name = first_id
                    return database_name
        return None

    @staticmethod
    def _removing_duplicates(input_file, database):
        with open(input_file, 'r') as file, tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.sdf') as temp_sdf:
            molecules = set()
            current_molecule = []
            in_molecule = False

            for line in file:
                if line.strip() == '$$$$':
                    if current_molecule:
                        first_line = current_molecule[0].strip()
                        if first_line:
                            mol_id = first_line.split()[0]
                            if mol_id not in molecules:
                                molecules.add(mol_id)
                                modified_molecule = [f"{mol_id}\n"] + current_molecule[1:]
                                temp_sdf.writelines(modified_molecule)
                                temp_sdf.write('$$$$\n')
                    current_molecule = []
                    in_molecule = False
                else:
                    if not in_molecule and line.strip():
                        in_molecule = True
                        current_molecule.append(line)
                    elif in_molecule:
                        current_molecule.append(line)

            if current_molecule:
                first_line = current_molecule[0].strip()
                if first_line:
                    mol_id = first_line.split()[0]
                    if mol_id not in molecules:
                        modified_molecule = [f"{mol_id}\n"] + current_molecule[1:]
                        temp_sdf.writelines(modified_molecule)
                        temp_sdf.write('$$$$\n')

            temp_file_name = temp_sdf.name
        return temp_file_name

    def _process_molecules(self, input_file, database, batch_size, affinity_cutoff,no_batch):
        included_molecules = set()
        current_batch = []
        molecule_count = 0
        file_index = 1
        
        with open(input_file, 'r') as file:
            current_molecule = []
            current_value = None
            
            for line in file:
                if not current_molecule and line.strip():
                    current_molecule = [line]
                    continue
                    
                current_molecule.append(line)
                
                if line.startswith("M  END"):
                    for next_line in file:
                        current_molecule.append(next_line)
                        if next_line.startswith('>'):
                            try:
                                value_line = next(file)
                                current_value = float(value_line.strip())
                                current_molecule.append(value_line)
                                break
                            except (ValueError, StopIteration) as e:
                                self.__log(f"Erro ao extrair valor de afinidade: {e}")
                                break
                                
                elif line.strip() == '$$$$':
                    first_line = current_molecule[0].strip()
                    mol_id = first_line.split()[0] if first_line else None
                    
                    if mol_id and (affinity_cutoff is None or (current_value is not None and current_value <= affinity_cutoff)):
                        if mol_id not in included_molecules:
                            included_molecules.add(mol_id)
                            modified_molecule = [f"{mol_id}\n"] + current_molecule[1:]
                            current_batch.extend(modified_molecule)
                            molecule_count += 1
                            
                            if batch_size and molecule_count == batch_size:
                                self.__save_batch(current_batch, database, file_index)
                                file_index += 1
                                current_batch = []
                                molecule_count = 0

                    current_molecule = []
                    current_value = None

        self.__log(f"Total de moléculas incluídas: {len(included_molecules)}")
        self.__log(f"Total de lotes criados: {file_index - 1}")

        if no_batch:
            return current_batch
        else:
            return included_molecules, file_index, current_batch
    

    def mk_addon(self, current_batch, database):
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.sdf') as temp_file:
            temp_file.writelines(current_batch)
        temp_file_path = temp_file.name
            
        df, first_prop_name = Merge()._extract_ids_affinities_from_sdf(temp_file_path)

        os.unlink(temp_file_path)

        os.makedirs('./addon', exist_ok=True)
                    
        output_csv = os.path.join("addon", f"{database}_addon.csv")

        if os.path.exists(output_csv):
            existing_df = pd.read_csv(output_csv)
            df = pd.concat([existing_df, df], ignore_index=True)
            df = df.drop_duplicates(subset='ID_Molecula', keep='first')
        
        df.to_csv(output_csv, index=False)

        return df, first_prop_name
    
    @staticmethod
    def __save_batch(batch, database, index):
        os.makedirs('./batchs', exist_ok=True)
        file_path = os.path.join("batchs", f"{database}_{index:04d}.sdf")
        with open(file_path, 'w') as f:
            f.writelines(batch)

    def make_addon(
        self,
        input_file: str, 
        batch_size: int = 299, 
        affinity_cutoff: float = None,
        no_batch: bool = False,
        verbose: bool = False,
        create_addon: bool = True,
 
    ) -> None:
        """        
        Use this function to split an SDF file into smaller SDFs that can be used for screening in ADMETlab 3.0. An auxiliary CSV file is also created, containing the molecule ID and SMILES notation. There is also an option to generate only the auxiliary CSV file without splitting the SDF into smaller parts by setting the no_batch=true parameter.

        Args:
            input_file (str): Path to the input file containing molecules.
            batch_size (int, optional): Number of molecules per batch. Defaults to 299.
            affinity_cutoff (float, optional): Affinity cutoff value for filtering molecules. Defaults to None.
            no_batch (bool, optional): If True, creates a single CSV file without batching. Defaults to False.
            verbose (bool, optional): If True, enables verbose logging. Defaults to False.
        Returns:
            None
        Raises:
            ValueError: If no molecules are found in the input file.
        """
        self.verbose = verbose
        self.__log(f"Processing {input_file}...")

        if batch_size is None:
            batch_size = 299

        database = self._extract_database_name(input_file)
        self.__log(f"Database: {database}")
        temp_file = self._removing_duplicates(input_file, database)
        input_file = temp_file

        if os.path.exists('batchs'):
                existing_files = [f for f in os.listdir("batchs") if f.startswith(database)]
                self.__log(f"Existing files in the batchs folder: {existing_files}")
                if existing_files:
                    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    database += '_' + timestamp
                    self.__log(f"New id name: {database}")

        if no_batch is True:
            self.__log("Creating just a csv with id, property and smiles")
            if os.path.exists('addon'):
                existing_files = [f for f in os.listdir("addon") if f.startswith(database)]
                self.__log(f"Existing files in the addon folder: {existing_files}")
                if existing_files:
                    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    database += '_' + timestamp
                    self.__log(f"New id name: {database}")
            current_batch = self._process_molecules(
                input_file, database, None, affinity_cutoff,no_batch
            )
            self.mk_addon(current_batch, database)
            return database, 0
        else:
            included_molecules, file_index, last_batch = self._process_molecules(
                input_file, database, batch_size, affinity_cutoff,no_batch
            )

            if last_batch:
                self.__save_batch(last_batch, database, file_index)

            all_batches = []
            for i in range(1, file_index + 1):
                batch_file_path = os.path.join("batchs", f"{database}_{i:04d}.sdf")
                with open(batch_file_path, 'r') as batch_file:
                    all_batches.extend(batch_file.readlines())

            if create_addon:
                self.mk_addon(all_batches, database)

            return database, file_index