from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from rich.box import ROUNDED, MINIMAL
from rich.style import Style
from .texts import*

class CustomPrint:
    def __init__(self):
        self.console = Console()
    
    def create_panel(self, content, title=None, border_style="white", box=ROUNDED, padding=(1, 1), title_align="left", expand=False):
        return Panel(
            content,
            title=title,
            box=box,
            padding=padding,
            border_style=border_style,
            title_align=title_align,
            expand=expand
        )

    def create_table(self, header_style=Style(color="#FFFFFF", bold=True)):
        table = Table(
            show_header=True,
            header_style=header_style,
            box=MINIMAL,
            show_lines=True,
            expand=False,
            border_style="white",
            padding=(0, 0)
        )
        table.add_column("Options", style=Style(color="#7B7B7B"), no_wrap=True)
        table.add_column("Description", style=Style(color="#FFFFFF"))
        return table

    def add_parser_actions_to_table(self, table, parser):
        for action in parser._actions:
            if action.option_strings:
                options = ", ".join(action.option_strings)
                table.add_row(options, action.help or "")

    def custom_help(self, parser):
        header_panel = self.create_panel(
            Text(description, style="white"),
            title="RankAdmet v1.2.0"
        )

        main_table = self.create_table()
        self.add_parser_actions_to_table(main_table, parser)
        main_panel = self.create_panel(main_table, title="Main Commands", padding=(0, 0))

        auto_panel = self.create_panel(
            Text(auto_help, justify="left"),
            title="Auto"
        )

        footer_panel = self.create_panel(
            Text(header, justify="center"),
            box=MINIMAL,
            expand=True,
            padding=(0, 0)
        )

        panels = ["\n", header_panel, main_panel, auto_panel, footer_panel, "\n"]
        for panel in panels:
            self.console.print(panel)

    def custom_help_subcommand(self, subparser, weights_note=None):

        if 'auto' in str(subparser.prog):
            command_type = 'auto'
        
        if command_type == 'auto':
            description = auto_description
        else:
            description = ""

        info_panel = self.create_panel(
            Text(description, justify="left"),
            title=command_type.capitalize()
        )

        sub_table = self.create_table()
        self.add_parser_actions_to_table(sub_table, subparser)
        sub_panel = self.create_panel(sub_table, title="Subcommand Help", padding=(0, 0))

        panels = ["\n", info_panel, sub_panel]
        
        if command_type == 'auto' and weights_note:
            note_panel = self.create_panel(
                Text(weights_note, justify="left"),
                title="Weights",
                padding=(1, 2, 1, 2)
            )
            panels.append(note_panel)

        footer_panel = self.create_panel(
            Text(header, justify="center"),
            box=MINIMAL,
            expand=True,
            padding=(0, 0)
        )
        panels.append(footer_panel)

        for panel in panels:
            self.console.print(panel)

    def custom_print(self, text, title):
        panel = self.create_panel(
            Text(text, justify="left"),
            title=title,
            padding=(1, 2, 0, 2)
        )
        self.console.print(panel)