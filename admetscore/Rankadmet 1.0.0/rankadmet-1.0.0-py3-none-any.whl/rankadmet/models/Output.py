import pandas as pd
import os

class Output:

    def __log(self, message: str):
        if self.verbose:
            print(message)

    @staticmethod
    def __get_column_letter(col_idx):
        letter = ''
        while col_idx > 0:
            col_idx, remainder = divmod(col_idx - 1, 26)
            letter = chr(65 + remainder) + letter
        return letter

    def __conditional_formatting_swissadme(self,df,excel_path,first_prop_name):
        writer = pd.ExcelWriter(excel_path, engine="xlsxwriter")
        df.to_excel(writer, sheet_name="Sheet1", index=False)
        workbook = writer.book
        worksheet = writer.sheets["Sheet1"]
        (max_row, max_col) = df.shape
        green_format = workbook.add_format({'bg_color': '#C6EFCE', 'font_color': '#006100'})
        yellow_format = workbook.add_format({'bg_color': '#FFEB9C', 'font_color': '#9C5700'})
        red_format = workbook.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006'})
        gray_format = workbook.add_format({'bg_color': '#D3D3D3'})
        number_format = workbook.add_format({'num_format': '0.000'})

        columns = ['SCORE','log_Kp','Synthetic_Accessibility']
        classes = ['ESOL Class','Ali Class','Silicos-IT class']
        inverse_columns = ['Bioavailability Score']
        low_high = ['GI absorption']
        string_columns = ['BBB permeant','Pgp substrate','CYP1A2 inhibitor','CYP2C19 inhibitor','CYP2C9 inhibitor','CYP2D6 inhibitor','CYP3A4 inhibitor']
        gray_columns = ['smiles','Formula','#Heavy atoms','#Aromatic heavy atoms','Fraction Csp3','#Rotatable bonds','#H-bond acceptors','#H-bond donors','MR','ESOL Solubility (mg/ml)','ESOL Solubility (mol/l)','Ali Solubility (mg/ml)','Ali Solubility (mol/l)','Silicos-IT Solubility (mg/ml)','Silicos-IT Solubility (mol/l)']

        additional_gray_columns = ['ID_Molecula',first_prop_name,'Match']

        special_conditions = {
            'Ghose #violations': [(0, 0, green_format), (1, float('inf'), red_format)],
            'Veber #violations': [(0, 0, green_format), (1, float('inf'), red_format)],
            'Egan #violations': [(0, 0, green_format), (1, float('inf'), red_format)],
            'Muegge #violations': [(0, 0, green_format), (1, float('inf'), red_format)], 
            'Bioavailability Score':[(1, 1, green_format), (0, float('inf'), red_format)],
            'PAINS #alerts': [(0, 0, green_format), (1, float('inf'), red_format)],
            'Brenk #alerts': [(0, 0, green_format), (1, float('inf'), red_format)],
            'Leadlikeness #violations' : [(0, 0, green_format), (1, float('inf'), red_format)],
            'MW': [(float('-inf'), 99.99, red_format), (100, 600, green_format),  (601.99, float('inf'), red_format)],
            'Lipinski #violations': [(float('-inf'), 2, green_format), (1, float('inf'), red_format)],
            'Silicos-IT LogSw':[(float('-inf'), -3.99, red_format),(-4, 0.5, green_format), (0.499, float('inf'), red_format)],
            'Ali Log S':[(float('-inf'), -3.99, red_format),(-4, 0.5, green_format), (0.499, float('inf'), red_format)],
            'ESOL Log S':[(float('-inf'), -3.99, red_format),(-4, 0.5, green_format), (0.499, float('inf'), red_format)],
            'iLOGP':[(float('-inf'), 0, red_format),(0, 3, green_format), (3, float('inf'), red_format)],
            'XLOGP3':[(float('-inf'), 0, red_format),(0, 3, green_format), (3, float('inf'), red_format)],
            'WLOGP':[(float('-inf'), 0, red_format),(0, 3, green_format), (3, float('inf'), red_format)],
            'MLOGP':[(float('-inf'), 0, red_format),(0, 3, green_format), (3, float('inf'), red_format)],
            'Silicos-IT Log P':[(float('-inf'), 0, red_format),(0, 3, green_format), (3, float('inf'), red_format)],
            'Consensus Log P':[(float('-inf'), 0, red_format),(0, 3, green_format), (3, float('inf'), red_format)],
            'TPSA':[(float('-inf'), 0, red_format),(0, 140, green_format), (140, float('inf'), red_format)],
        }

        numeric_cols = df.select_dtypes(include=['number']).columns
        for col_name in numeric_cols:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.set_column(f'{col_letter}:{col_letter}', None, number_format)

        for col_name in columns:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.0, 'maximum': 0.300, 'format': green_format})
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.3000000000001, 'maximum': 0.700, 'format': yellow_format})
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.7000000000001, 'maximum': 100.0, 'format': red_format})

        for col_name in inverse_columns:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.0, 'maximum': 0.300, 'format': red_format})
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.3000000000001, 'maximum': 0.700, 'format': yellow_format})
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.7000000000001, 'maximum': 1.0, 'format': green_format})

        for col_name in string_columns:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'containing', 'value': "No", 'format': green_format})
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'not containing', 'value': "No", 'format': red_format})

        for col_name in classes:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'containing', 'value': "Poorly", 'format': red_format})
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'containing', 'value': "Moderately", 'format': red_format})
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'containing', 'value': "Insoluble", 'format': red_format})
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'not containing', 'value': "Poorly", 'format': green_format})
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'not containing', 'value': "Moderately", 'format': green_format})

        for col_name in low_high:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'containing', 'value': "High", 'format': green_format})
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'not containing', 'value': "High", 'format': red_format})

        for col_name, conditions in special_conditions.items():
            col_idx = df.columns.get_loc(col_name)  
            col_letter = self.__get_column_letter(col_idx + 1)  
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'

            for min_val, max_val, fmt in conditions:
                criteria = 'between'
                if min_val == float('-inf'):
                    criteria = 'less than or equal to'
                    min_val = max_val
                elif max_val == float('inf'):
                    criteria = 'greater than or equal to'
                    max_val = min_val
                worksheet.conditional_format(cell_range, {
                    'type': 'cell',
                    'criteria': criteria,
                    'minimum': min_val,
                    'maximum': max_val,
                    'format': fmt
                })
        for col_name in gray_columns:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.conditional_format(cell_range, {'type': 'no_blanks', 'format': gray_format})
        try:
            for col_name in additional_gray_columns:
                col_idx = df.columns.get_loc(col_name)
                col_letter = self.__get_column_letter(col_idx + 1)
                cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
                worksheet.conditional_format(cell_range, {'type': 'no_blanks', 'format': gray_format})
        except:
            pass    
        writer.close()

    def __conditional_formatting_admetlab(self,df,excel_path,first_prop_name):
        writer = pd.ExcelWriter(excel_path, engine="xlsxwriter")
        df.to_excel(writer, sheet_name="Sheet1", index=False)
        workbook = writer.book
        worksheet = writer.sheets["Sheet1"]
        (max_row, max_col) = df.shape
        green_format = workbook.add_format({'bg_color': '#C6EFCE', 'font_color': '#006100'})
        yellow_format = workbook.add_format({'bg_color': '#FFEB9C', 'font_color': '#9C5700'})
        red_format = workbook.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006'})
        gray_format = workbook.add_format({'bg_color': '#D3D3D3'})
        number_format = workbook.add_format({'num_format': '0.000'})

        columns = ['PAMPA', 'pgp_inh', 'pgp_sub', 'hia', 'f20', 'f30', 'f50','OATP1B1', 'OATP1B3','BSEP', 'BBB', 'MRP1','hERG', 'hERG-10um', 'DILI', 'Ames', 'ROA', 'FDAMDD', 'SkinSen', 'Carcinogenicity', 'EC', 'EI', 'Respiratory', 'H-HT', 'Neurotoxicity-DI', 'Ototoxicity', 'Hematotoxicity', 'Nephrotoxicity-DI', 'Genotoxicity', 'RPMI-8226', 'A549', 'HEK293','NR-AhR', 'NR-AR', 'NR-AR-LBD', 'NR-Aromatase', 'NR-ER', 'NR-ER-LBD', 'NR-PPAR-gamma', 'SR-ARE', 'SR-ATAD5', 'SR-HSE', 'SR-MMP', 'SR-p53','CYP1A2-inh', 'CYP1A2-sub', 'CYP2C19-inh', 'CYP2C19-sub', 'CYP2C9-inh', 'CYP2C9-sub', 'CYP2D6-inh', 'CYP2D6-sub', 'CYP3A4-inh', 'CYP3A4-sub', 'CYP2B6-inh', 'CYP2B6-sub', 'CYP2C8-inh','Aggregators', 'Fluc', 'Blue_fluorescence', 'Green_fluorescence', 'Reactive', 'Promiscuous','SCORE', 'ABSORTION', 'DISTRIBUTION', 'TOXICITY', 'TOX21_PATHWAY', 'METABOLISM', 'TOXICOPHORE_RULES', 'EXCRETION', 'MEDICINAL_CHEMISTRY','Synthesis_profile','Drug_likeness_profile','LM-human','BCRP','Physicochemical_Property']

        string_columns = ['NonBiodegradable', 'NonGenotoxic_Carcinogenicity', 'SureChEMBL', 'Skin_Sensitization', 'Acute_Aquatic_Toxicity', 'Genotoxic_Carcinogenicity_Mutagenicity','FAF-Drugs4 Rule','Alarm_NMR', 'BMS', 'Chelating', 'PAINS']

        gray_columns = ['smiles','Vol','Dense','Flex','Natural Product-likeness','mp','bp','pka_acidic','pka_basic','BCF','IGC50','LC50DM','LC50FM','Other_assay_interference','LD50_oral']

        additional_gray_columns = ['ID_Molecula',first_prop_name,'Match']

        special_conditions = {
            'Lipinski': [(0, 0, green_format), (1, float('inf'), red_format)],
            'Pfizer': [(0, 0, green_format), (1, float('inf'), red_format)],
            'gasa': [(0, 0, green_format), (1, 1, red_format)],
            'Synth': [(float('-inf'), 6.0, green_format), (6.001, float('inf'), red_format)],
            'GoldenTriangle': [(float('-inf'), 0, green_format), (1, float('inf'), red_format)],
            'GSK': [(float('-inf'), 0, green_format), (1, float('inf'), red_format)],
            'MDCK':[(2e-6, float('inf'), green_format), (float('-inf'), 2e-6, red_format)],            
            'caco2': [(-5150, float('inf'), green_format), (float('-inf'), -5150.01, red_format)],
            'QED': [(670, float('inf'), green_format), (490, 669.99, yellow_format), (float('-inf'), 489.99, red_format)],
            't_0_5': [(8, float('inf'), green_format), (1, 7.9, yellow_format), (float('-inf'), 0, red_format)],
            'PPB': [(float('-inf'), 90, green_format), (90.01, float('inf'), red_format)],
            'Fsp3': [(420, float('inf'), green_format), (float('-inf'), 419, red_format)],
            'MCE_18': [(45.0, float('inf'), green_format), (float('-inf'), 44.999, red_format)],
            'Fu': [(5, float('inf'), green_format), (float('-inf'), 4.99, red_format)],
            'cl_plasma': [(0, 5, green_format), (5.01, 15, yellow_format), (15.01, float('inf'), red_format)],
            'logVDss': [(40, 200, green_format), (float('-inf'), 39.99, red_format), (200.01, float('inf'), red_format)],
            'MW': [(100, 600, green_format), (float('-inf'), 99.99, red_format), (600.01, float('inf'), red_format)],
            'logD': [(1, 3, green_format), (float('-inf'), 0.99, red_format), (3.01, float('inf'), red_format)],
            'nHet': [(0, 15, green_format), (15.01, float('inf'), red_format)],
            'nHD': [(0, 7, green_format), (7.01, float('inf'), red_format)],
            'nRing': [(0, 6, green_format), (6.01, float('inf'), red_format)],
            'nRig': [(0, 30, green_format), (30.01, float('inf'), red_format)],
            'logP': [(3, 5, green_format), (float('-inf'), 2.99, red_format), (5.01, float('inf'), red_format)],
            'MaxRing': [(0, 18, green_format), (18.01, float('inf'), red_format)],
            'TPSA': [(0, 139.999, green_format), (140, float('inf'), red_format)],
            'nHA': [(0, 12, green_format), (12.01, float('inf'), red_format)],
            'nRot': [(0, 11, green_format), (11.01, float('inf'), red_format)],
            'nStereo': [(0, 2, green_format), (2.01, float('inf'), red_format)],
            'fChar': [(-4, 4, green_format), (4.01, float('inf'), red_format)],
            'logS': [(-4, 0.5, green_format), (0.51, float('inf'), red_format), (float('-inf'), -4.01, red_format)],
        }

        numeric_cols = df.select_dtypes(include=['number']).columns
        for col_name in numeric_cols:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.set_column(f'{col_letter}:{col_letter}', None, number_format)
        for col_name in columns:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.0, 'maximum': 0.300, 'format': green_format})
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.3000000000001, 'maximum': 0.700, 'format': yellow_format})
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.7000000000001, 'maximum': 1.0, 'format': red_format})
        # inverted_values = ['BCRP','LM-human']
        # for i in inverted_values:
        #     cold_idx = df.columns.get_loc(i)
        #     col_letter = self.__get_column_letter(cold_idx + 1)
        #     cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
        #     worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.7000000000001, 'maximum': 1.0, 'format': green_format})
        #     worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.3000000000001, 'maximum': 0.700, 'format': yellow_format})
        #     worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0.0, 'maximum': 0.300, 'format': red_format})
        for col_name in string_columns:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'containing', 'value': "['-']", 'format': green_format})
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'not containing', 'value': "['-']", 'format': red_format})

        for col_name, conditions in special_conditions.items():
            col_idx = df.columns.get_loc(col_name)  
            col_letter = self.__get_column_letter(col_idx + 1)  
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            for min_val, max_val, fmt in conditions:
                criteria = 'between'
                if min_val == float('-inf'):
                    criteria = 'less than or equal to'
                    min_val = max_val
                elif max_val == float('inf'):
                    criteria = 'greater than or equal to'
                    max_val = min_val
                worksheet.conditional_format(cell_range, {
                    'type': 'cell',
                    'criteria': criteria,
                    'minimum': min_val,
                    'maximum': max_val,
                    'format': fmt
                })
    
        for col_name in gray_columns:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.conditional_format(cell_range, {'type': 'no_blanks', 'format': gray_format})
        try:
            for col_name in additional_gray_columns:
                col_idx = df.columns.get_loc(col_name)
                col_letter = self.__get_column_letter(col_idx + 1)
                cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
                worksheet.conditional_format(cell_range, {'type': 'no_blanks', 'format': gray_format})
        except:
            pass 
        writer.close()

    def __making_top_best_file(self, df, best_hits, site, first_prop_name):
        excel_top_path = os.path.join(f'rankadmet_Top{best_hits}_{site}.xlsx')
        top_df = df.head(best_hits)
        if site == 'admetlab':
            self.__conditional_formatting_admetlab(top_df, excel_top_path,first_prop_name)
        elif site == 'swissadme':
            self.__conditional_formatting_swissadme(top_df, excel_top_path,first_prop_name)

    def drop_duplicates(self,df):
            if 'ID_Molecula' in df.columns:
                df.drop_duplicates(subset='ID_Molecula', keep='first', inplace=True)
            else:
                df.drop_duplicates(subset='smiles', keep="first", inplace=True)
            return df

    def output_handled(
        self, 
        df, 
        best_hits, 
        site, 
        first_prop_name,
        verbose: bool = False
    ) -> None:
        
        self.verbose = verbose
        if best_hits is None:
            best_hits = 50

        excel_path = os.path.join(f'rankadmet_{site}.xlsx')

        if os.path.exists(excel_path):
            existing_df = pd.read_excel(excel_path, sheet_name='Sheet1')
            initial_count = len(existing_df)
            existing_df = existing_df.dropna(how='all', axis=1)
            df = df.dropna(how='all', axis=1)
            updated_df = pd.concat([existing_df, df], ignore_index=True)
            updated_df = updated_df.sort_values(by='SCORE', ascending=True)
            updated_df = self.drop_duplicates(updated_df)
            final_count = len(updated_df)
            new_entries = final_count - initial_count
            self.__log(f'{new_entries} new molecules have been added. Final count: {final_count}\n')

        else:
            updated_df = df           
            updated_df = updated_df.sort_values(by='SCORE', ascending=True)
            updated_df = self.drop_duplicates(updated_df)
            final_count = len(updated_df)
            self.__log(f'The spreadsheet was created with {final_count} molecules.\n')

        self.__making_top_best_file(updated_df, best_hits, site , first_prop_name)

        if site == 'admetlab':
            self.__conditional_formatting_admetlab(updated_df, excel_path, first_prop_name)
        elif site == 'swissadme':
            self.__conditional_formatting_swissadme(updated_df, excel_path, first_prop_name)
