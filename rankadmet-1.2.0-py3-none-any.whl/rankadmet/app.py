from rich.progress import Progress, TextColumn, BarColumn, TaskProgressColumn
from rich.console import Console
from .models.BrowserHandler import *
from .models.CustomPrint import *
from .models.Addon import *
from .models.Evaluate import *
from .models.Merge import *
from .models.Output import *
from .models.texts import *
import pandas as pd
import requests
import argparse
import glob
import json
import os

def weight():
    Evaluate.json()
    with open('weights.json','r') as json_file:
        weights = json.load(json_file)
    
    return weights
def set_weight():
    weights = weight()
    groups = weights["admetlab"][0]["groups"]

    json_weights = ''
    for key, value in groups.items():
        json_weights += f"{key}: {value}\n"

    weights_note = f"{json_weights}{message_weights}"

    return weights_note

console = Console()
weights_note = set_weight()

def main():

    global weights_note

    parser = argparse.ArgumentParser(
        description=header,
        add_help=False
    )
    parser.add_argument('--sdf', action='store_true', help=sdf_folder)
    parser.add_argument('--csv', action='store_true', help=csv_folder)
    parser.add_argument('-i', '--input', type=str, nargs='+', help=default_input)
    parser.add_argument('-a', '--addon', type=str, default=None, help=addon)
    parser.add_argument('-t', '--top_hits', type=int, help=top_hits)
    parser.add_argument('-bs', '--batch_size', type=int, help=batch_size)
    parser.add_argument('-ps','--pharmit_score', type=float, help=pharmit_score)
    parser.add_argument('-nb', '--no_batch', action='store_true', help=no_batch)
    parser.add_argument('-h', '--help', action='store_true', help=help_parameter)

    subparsers = parser.add_subparsers(dest='tool', help=description)

    parser_auto = subparsers.add_parser(
        'auto',
        description=header + auto_description,
        add_help=False
    )
    parser_auto.add_argument('--resume', action='store_true', help=resume)
    parser_auto.add_argument('-i', '--input', type=str, nargs='+', help=auto_input)
    parser_auto.add_argument('-bs', '--batch_size', type=int, default=299, help=batch_size)
    parser_auto.add_argument('-ps', '--pharmit_score', type=float, help=pharmit_score)
    parser_auto.add_argument('-t', '--top_hits', type=int, default=50, help=top_hits)
    parser_auto.add_argument('-h','--help', action='store_true', help=help_parameter)

    args = parser.parse_args()
    if args.tool is None and args.input is None:
        CustomPrint().custom_help(parser)
    else:
        if args.tool is None:
            decision_inputs(args.sdf, args.csv, args.input, args.addon, args.top_hits, args.batch_size, args.pharmit_score, args.no_batch, args.help)
        elif args.tool == 'auto':
            auto(args.resume, args.input, args.batch_size, args.pharmit_score, args.top_hits, args.help, parser_auto)
        else:
            print(usage)

# Functions for each program functionality
def auto(resume, sdf_file, batch_size, pharmit_score, top_hits, hp, parser_auto):

    if hp == True or sdf_file is None:
        CustomPrint().custom_help_subcommand(parser_auto, weights_note)
        return

    no_batch = False

    try:
        print('Testing connection with AdmetLab')
        response = requests.get("https://admetlab3.scbdd.com/", timeout=10)
        console.clear()
        match response.status_code:
            case 200:
                CustomPrint().custom_print(weights_note, 'Weights Used in Scores:')
                all_sdf_files = []    
                for input_path in sdf_file:
                    if os.path.isdir(input_path):
                        all_sdf_files.extend(glob.glob(os.path.join(input_path, '*.sdf')))
                    else:
                        all_sdf_files.append(input_path)

                for sdf in all_sdf_files:
                    if not resume:
                        check = mkaddon([sdf], batch_size, pharmit_score, no_batch, create_addon=False,folder=False)
                        if check == False:
                            return
                    BrowserHandler().run_tasks(top_hits)

            case 404:
                return console.print(f"[red]\nError 404: Page not found. AdmetLab is currently unavailable.\n[/red]")
            case 500:
                return console.print(f"[red]\nError 500: Internal Server Error. The server is currently unavailable.\n[/red]")
    except Exception as e:
        erro = type(e).__name__
        match erro:
            case "ConnectionError":
                return console.print(f"[red]\nError connecting to AdmetLab. Check your internet connection or the server's availability.\n[/red]")
            case "ReadTimeout":
                return console.print(f"[red]\nResponse timeout reached. Unable to access AdmetLab right now. Please try again later.\n[/red]")
            case "SSLError":
                return console.print(f"[red]\nThe automatic mode cannot proceed because AdmetLab is experiencing an SSL certificate error. However, it can still be accessed manually via a web browser.\n[/red]")
            case _:
                return console.print(f"[red]\nAn unexpected error occurred: {erro}[/red]\n")

def mkaddon(sdf_files, batch_size, pharmit_score, no_batch, create_addon, folder):
    
    database_summary = {}
    with Progress(
        TextColumn('[progress.description]{task.description}'),
        BarColumn(),
        TaskProgressColumn(),
    ) as progress:

        overall_task = progress.add_task(f"[#FFFFFF]Processing {len(sdf_files)} sdf files...", total=len(sdf_files))
        
        for sdf_file in sdf_files:
            
            try:
                file_task = progress.add_task(f"[#7B7B7B]Processing {os.path.basename(sdf_file)}", total=100)
                progress.update(file_task, completed=1)
                database, file_index = Addon().make_addon(sdf_file, batch_size, pharmit_score, no_batch, create_addon=create_addon, folder=folder)
                match database:
                    case 'CSC':
                        database = 'ChemSpace'
                    case 'Z':
                        database = 'Enamine'
                    case 'LN':
                        database = 'WuXi LabNetwork'
                    case 'NSC':
                        database = 'NCI Open Chemical Repository'
                    case _:
                        pass

                if database not in database_summary:
                    database_summary[database] = {
                        'total_files': 1,
                        'total_partitions': file_index
                    }
                else:
                    database_summary[database]['total_files'] += 1
                    database_summary[database]['total_partitions'] += file_index

                for i in range(11, 101):
                    progress.update(file_task, completed=i)
                    time.sleep(0.009)

                progress.update(file_task, completed=100)
            
            except Exception as e:
                progress.update(file_task, completed=0)
                progress.console.print(f"[red]{e}")
                return False
            
            progress.update(overall_task, advance=1)

    if file_index == 0:
        summary_output = ''
        for db_name, info in database_summary.items():
            summary_output += (
            f"{db_name}\n"
            )
        print('')
        CustomPrint().custom_print(summary_output,'Addon made for the following databases:')
    else:        
        summary_output = ''
        for db_name, info in database_summary.items():
            summary_output += (
            f"{db_name}: {info['total_partitions']}\n"
            )
        print('')
        CustomPrint().custom_print(summary_output,'Partitions created:')

    for i in sdf_files:
        ok_sdf_file = i.replace('.sdf', '_ok.sdf')
        os.rename(i, ok_sdf_file)
def evaluate(input_files, website, addon, top_hits):

    if addon is not None and '_ok' in addon:
        console.print(f"[red]Error: The add-on file {addon} has already been processed and contains '_ok' in its name.[/red]")
        return

    print('')
    CustomPrint().custom_print(weights_note, f'{website} spreadsheet analysis, with the weights:')

    with Progress(
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
    ) as progress:

        overall_task = progress.add_task(f"[#FFFFFF]Evaluating each of the {len(input_files)} csv files...", total=len(input_files))

        all_dfs = []

        for csv_file in input_files:
            file_task = progress.add_task(f"[#7B7B7B]Evaluating {os.path.basename(csv_file)} file", total=100)
            
            try:
                df = pd.read_csv(csv_file)

                if website == 'admetlab':
                    df = Evaluate().score_admetlab(df)
                elif website == 'swissadme':
                    df = Evaluate().score_swissadme(df)
                elif website == 'admetai':
                    df = Evaluate().score_admetai(df)

                all_dfs.append(df)

                progress.update(file_task, completed=100)
            except Exception as e:
                progress.console.print(f"[red]Error! {csv_file}: {e}")
                progress.update(file_task, completed=0)
                continue

            progress.update(overall_task, advance=1)

        file_task = progress.add_task("[#FFFFFF]Consolidating Spreadsheet", total=100)

        for i in range(0, 21):
            progress.update(file_task, completed=i)
            time.sleep(0.009)

        if all_dfs:
            final_df = pd.concat(all_dfs, ignore_index=True)
        else:
            progress.console.print("[red]No DataFrame was generated for concatenation[/red]")
            final_df = None

        if final_df is not None and not final_df.empty:

            try:
                first_prop_name = None
                if addon is not None:
                    df,first_prop_name = Evaluate().addon_verification(final_df, addon)

            except Exception as e:
                progress.console.print(f'[red]Error with the add-on file: {e}[/red]')
                raise
            
            Output().output_handled(df, top_hits, website, first_prop_name,verbose=True)
            progress.update(file_task, completed=100)

            for csv_file in input_files:
                os.remove(csv_file)
            
            
            if addon:
                os.remove(addon)

# Treatment for files
def filter_processed_files(files):

    length = len(files)
    filtered_files = [file for file in files if not file.endswith('_ok' + os.path.splitext(file)[1])]
    diff = length - len(filtered_files)
    
    return filtered_files, diff
def log_file_processing(file_type, filtered_files, diff):

    if file_type == 'sdf':
        print("")
        CustomPrint().custom_print('Making add-on files', 'Running:')
    elif file_type == 'csv':
        CustomPrint().custom_print('Creating analysis spreadsheet', 'Running:')
    
    if diff != 0:
        console.print(f"[yellow]{diff} {file_type} files has the '_ok' tag indicating that it has already been processed[/yellow]")
    if len(filtered_files) == 0:
        console.print(f"[red]No {file_type} files to be processed[/red]\n")
        return
    console.print(f"[green]{len(filtered_files)} {file_type} files found[/green]")

# Treatment for csv files
def categorize_csv_files(csv_files):

    admetlab_list = []
    swissadme_list = []
    admetai_list = []

    for csv_file in csv_files:
        df = pd.read_csv(csv_file)
        if 'gasa' in df.columns:
            admetlab_list.append(csv_file)
        elif 'ESOL Log S' in df.columns:
            swissadme_list.append(csv_file)
        elif 'molecular_weight_drugbank_approved_percentile' in df.columns:
            admetai_list.append(csv_file)
        else:
            console.print(f"[yellow]Warning: {os.path.basename(csv_file)} is not a valid AdmetLab or SwissADME file[/yellow]")

    return admetlab_list, swissadme_list, admetai_list
# Treatment for sdf files
def addon_sdf(sdf_files, batch_size, pharmit_score, no_batch,folder=False):
    filtered_sdf_files, diff = filter_processed_files(sdf_files)
    if filtered_sdf_files:
        log_file_processing('sdf', filtered_sdf_files, diff)
        if filtered_sdf_files:
            if no_batch:
                mkaddon(filtered_sdf_files, batch_size, pharmit_score, True, True,folder)
                return
            else:
                mkaddon(filtered_sdf_files, batch_size, pharmit_score, False, True,folder)
                return
    else:
        console.print('[red]\nNo sdf files were found in the folder. Please check if the files are tagged with _ok\n[/red]')
        return       

# Contextualizing user input
def evaluate_csv(csv_files, addon, top_hits):

    filtered_csv_files, diff = filter_processed_files(csv_files)
    if filtered_csv_files:
        log_file_processing('csv', filtered_csv_files, diff)
        admetlab_list, swissadme_list, admetai_list = categorize_csv_files(filtered_csv_files)
        if admetlab_list and swissadme_list:
            console.print(f"[red]Error: Both AdmetLab and SwissADME files were found in the folder. Please ensure only files from a single source are present, or specify the file paths to process.[/red]")
            return
        if admetlab_list:
            evaluate(admetlab_list,'admetlab', addon, top_hits)
            return
        if not admetlab_list and swissadme_list:
            evaluate(swissadme_list,'swissadme', addon, top_hits)
            return
        if not admetlab_list and not swissadme_list and admetai_list:
            evaluate(admetai_list,'admetai', addon, top_hits)
            return

    else:
        console.print('[red]\nNo csv files were found in the folder. Please check if the files are tagged with _ok\n[/red]')
        return
def decision_inputs(flagSDF,flagCSV,input, addon, top_hits, batch_size, pharmit_score, no_batch, help):

    sdf_files = []
    csv_files = []

    folders = [path for path in input if os.path.isdir(path)]
    file_paths = [path for path in input if os.path.isfile(path)]

    if folders and file_paths:
        console.print(f'[red]\nError: Mixed input types detected. Please provide a single folder/file or multiple files.\n[/red]')
        return

    if folders:
        if len(folders) > 1:
            console.print(f'[red]\nError: Multiple folders detected. Only one folder is allowed at a time. Folders found: {folders}\n[/red]')
            return

        for i in folders:
            sdf_files.extend(
                [file for file in glob.glob(os.path.join(i, '*.sdf'))]
            )
            csv_files.extend(
                [file for file in glob.glob(os.path.join(i, '*.csv'))]
            )

        if no_batch is False:
            no_batch = None

        param_sdf = [flagSDF, batch_size, pharmit_score, no_batch]
        param_csv = [flagCSV, addon, top_hits]

        if any(param_sdf) and any(param_csv):
            console.print(parameter_conflict)
            return
        elif any(param_sdf):
            if sdf_files:
                filtered_sdf_files, diff = filter_processed_files(sdf_files)

                if filtered_sdf_files:
                        if filtered_sdf_files:
                            
                            temp_file_path = Addon().agglomerate(sdf_files)
                            file_temp = [temp_file_path]
                            folder = True
                            
                else:
                    console.print('[red]\nNo sdf files were found in the folder. Please check if the files are tagged with _ok\n[/red]')
                    return  
                
                addon_sdf(file_temp, batch_size, pharmit_score, no_batch,folder)
            else:
                console.print(no_sdf_found)
                return
        elif any(param_csv):
            if csv_files:
                evaluate_csv(csv_files, addon, top_hits)
            else:
                console.print(no_csv_found)
                return
        else:
            console.print(type_error)

    if file_paths:
        extensions = set(os.path.splitext(path)[1].lower() for path in file_paths)
        if len(extensions) > 1:
            console.print(f'[red]\nError: Multiple file extensions found.[/red]\n[yellow]Only .sdf or .csv files are allowed. Extensions found: {extensions}\n[/yellow]')
            return
        ext = extensions.pop()
        if ext not in ['.sdf', '.csv']:
            console.print(f'[red]\nError: Invalid file extension.[/red]\n[yellow]Only .sdf and .csv files are allowed, {ext} is not permitted.\n[/yellow]')
            return

        param_sdf = [batch_size, pharmit_score, no_batch]
        param_csv = [addon, top_hits]

        if any(param_sdf) and any(param_csv):
            console.print(parameter_conflict)
            return
        elif any(param_sdf) and ext == '.csv':
            console.print(parameter_conflict)
            return
        elif any(param_csv) and ext == '.sdf':
            console.print(parameter_conflict)
            return
        elif any(param_sdf) and ext == '.sdf':
            addon_sdf(file_paths, batch_size, pharmit_score, no_batch)
        elif any(param_csv) and ext == '.csv':
            evaluate_csv(file_paths, addon, top_hits)
        else:
            if ext == '.sdf':
                addon_sdf(file_paths, batch_size, pharmit_score, no_batch)
            else:
                evaluate_csv(file_paths, addon, top_hits)

    if not folders and not file_paths:
        console.print('[red]\nError: No input files or folders found[/red]')
        return

# Main function
if __name__ == '__main__':
    main()