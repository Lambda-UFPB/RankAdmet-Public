import pandas as pd
import os

class Output:

    def __init__(self, verbose = False):
        self.verbose = verbose


    @staticmethod
    def __get_column_letter(col_idx):
        """
        Converts a column index to its corresponding letter representation.
        """
        letter = ''
        while col_idx > 0:
            col_idx, remainder = divmod(col_idx - 1, 26)
            letter = chr(65 + remainder) + letter
        return letter

    def __conditional_formatting(self,df,excel_path):
        """
        Apply conditional formatting to an Excel file based on specified rules. The function uses the xlsxwriter library to write the formatted data.
        """
        writer = pd.ExcelWriter(excel_path, engine="xlsxwriter")

        df.to_excel(writer, sheet_name="Sheet1", index=False)

        workbook = writer.book
        worksheet = writer.sheets["Sheet1"]

        (max_row, max_col) = df.shape

        green_format = workbook.add_format({'bg_color': '#C6EFCE', 'font_color': '#006100'})
        yellow_format = workbook.add_format({'bg_color': '#FFEB9C', 'font_color': '#9C5700'})
        red_format = workbook.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006'})
        gray_format = workbook.add_format({'bg_color': '#D3D3D3'})
        number_format = workbook.add_format({'num_format': '0.00'})
        center_format = workbook.add_format({'align': 'center', 'valign': 'vcenter'}) 


        columns = [49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 125, 126, 127, 128, 129, 131]

        string_columns = [32, 33, 34, 35, 117, 118, 119, 120, 121, 122, 123, 124]

        gray_columns = [0,1,11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 31, 40, 41, 42, 43, 44, 45, 46, 48, 81, 82, 83, 84, 130]

        scores_columns = [2,3,4,5,6,7,8,9,10]

        special_conditions = {
            38: [(0, 0, green_format), (1, float('inf'), red_format)],
            39: [(0, 0, green_format), (1, float('inf'), red_format)],
            26: [(1, 1, green_format), (0, 0, red_format)],
            28: [(float('-inf'), 6000, green_format), (6000.01, float('inf'), red_format)],
            36: [(float('-inf'), 0, green_format), (1, float('inf'), red_format)],
            37: [(float('-inf'), 0, green_format), (1, float('inf'), red_format)],
            47: [(-5150, float('inf'), green_format), (float('-inf'), -5150.01, red_format)],
            27: [(670, float('inf'), green_format), (490, 669.99, yellow_format), (float('-inf'), 489.99, red_format)],
            80: [(8, float('inf'), green_format), (1, 7.9, yellow_format), (float('-inf'), 0, red_format)],
            62: [(float('-inf'), 90, green_format), (90.01, float('inf'), red_format)],
            29: [(420, float('inf'), green_format), (float('-inf'), 419, red_format)],
            30: [(45000, float('inf'), green_format), (float('-inf'), 44999.99, red_format)],
            64: [(5, float('inf'), green_format), (float('-inf'), 4.99, red_format)],
            79: [(0, 5, green_format), (5.01, 15, yellow_format), (15.01, float('inf'), red_format)],
            63: [(40, 200, green_format), (float('-inf'), 39.99, red_format), (200.01, float('inf'), red_format)]
        }

        numeric_cols = df.select_dtypes(include=['number']).columns
        for col_name in numeric_cols:
            col_idx = df.columns.get_loc(col_name)
            col_letter = self.__get_column_letter(col_idx + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            worksheet.set_column(f'{col_letter}:{col_letter}', None, number_format)


        for col in columns:
            col_letter = self.__get_column_letter(col + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0, 'maximum': 300, 'format': green_format})
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 300.01, 'maximum': 700, 'format': yellow_format})
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 700.01, 'maximum': 1000, 'format': red_format})

        for col in scores_columns:
            col_letter = self.__get_column_letter(col + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'
            
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 7, 'maximum': 10, 'format': green_format})
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 4, 'maximum': 6.99, 'format': yellow_format})
            worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': 'between', 'minimum': 0, 'maximum': 3.99, 'format': red_format})

        for col in string_columns:
            col_letter = self.__get_column_letter(col + 1)
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'

            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'containing', 'value': "['-']", 'format': green_format})
            worksheet.conditional_format(cell_range, {'type': 'text', 'criteria': 'not containing', 'value': "['-']", 'format': red_format})

        for col, conditions in special_conditions.items():
            col_letter = self.__get_column_letter(col + 1) 
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'

            for min_val, max_val, fmt in conditions:
                criteria = 'between'
                if min_val == float('-inf'):
                    criteria = 'less than or equal to'
                    min_val = max_val
                elif max_val == float('inf'):
                    criteria = 'greater than or equal to'
                    max_val = min_val

                worksheet.conditional_format(cell_range, {'type': 'cell', 'criteria': criteria, 'minimum': min_val, 'maximum': max_val, 'format': fmt})
    
        for col in gray_columns:
            col_letter = self.__get_column_letter(col + 1)  # Adicionar 1 porque as colunas são 1-indexadas no Excel
            cell_range = f'{col_letter}2:{col_letter}{max_row + 1}'

            worksheet.conditional_format(cell_range, {'type': 'no_blanks', 'format': gray_format})

        worksheet.set_column(f'{col_letter}:{col_letter}', None, workbook.add_format({'num_format': '0.00'}))

        #for col_idx in range(max_col):
        #    col_letter = self.__get_column_letter(col_idx + 1)
        #    worksheet.set_column(f'{col_letter}:{col_letter}', None, center_format)

        writer.close()

    def __log(self, message: str):
        '''Helper method to print messages if verbose mode is enabled'''
        if self.verbose:
            print(message)

    def __making_top_best_file(self,df,best_hits):
        """
        Creates an Excel file with the top best molecules based on the given dataframe.
        """
        excel_top_path = os.path.join(f'scoreadmet_{best_hits}_tops.xlsx')
        top_df = df.head(best_hits)
        self.__conditional_formatting(top_df, excel_top_path)
        

    def output(self,df,best_hits,flag):
        """
        Updates an existing Excel spreadsheet or creates a new one with the given DataFrame.
        """

        excel_path = os.path.join('scoreadmet.xlsx')

        if os.path.exists(excel_path):
            existing_df = pd.read_excel(excel_path, sheet_name='Sheet1')
            initial_count = len(existing_df)
            updated_df = pd.concat([existing_df, df], ignore_index=True)
            updated_df = updated_df.sort_values(by='SCORE', ascending=False)
            updated_df.drop_duplicates(subset='ID_Molecula', keep="first", inplace=True)
            final_count = len(updated_df)
            new_entries = final_count - initial_count
            if flag == False:
                self.__log(f'\n{new_entries} new molecules were added.\n')
        else:
            updated_df = df
            updated_df = updated_df.sort_values(by='SCORE', ascending=False)
            updated_df.drop_duplicates(subset='ID_Molecula', keep='first', inplace=True)
            final_count = len(updated_df)
            if flag == False:
                self.__log(f'\nThe spreadsheet was created with {final_count} molecules.\n')

        self.__making_top_best_file(updated_df,best_hits)
        self.__conditional_formatting(updated_df,excel_path)

        return updated_df